(() => {
  const dialogs=[...document.querySelectorAll('.menu-dialog')];
  const heroLore=document.getElementById('hero-lore');
  function selectHero(id){
    if(!window.AstraCharacters[id])return;
    window.AstraSelectedCharacter=id;heroLore.textContent=window.AstraCharacters[id].lore;
    document.getElementById('selected-hero-name').textContent=window.AstraCharacters[id].name;
    for(const button of document.querySelectorAll('[data-hero]'))button.setAttribute('aria-pressed',String(button.dataset.hero===id));
    try{localStorage.setItem('astra-character',id);}catch{}
  }
  for(const button of document.querySelectorAll('[data-hero]'))button.onclick=()=>selectHero(button.dataset.hero);
  selectHero(window.AstraSelectedCharacter);
  const chapters=[
    ['01 / 별의 추락','별은 하늘에서 죽지 않았다.','천 년 동안 성소 위에서 타오르던 별은, 어느 날 소리 없이 갈라졌다. 떨어진 빛은 대지를 축복하지 않았다. 별의 심장에 갇혀 있던 공허가 깨어나 죽은 자를 일으키고, 도시의 이름을 지워 버렸다.','살아남은 이들은 마지막 성소로 모였다. 그곳에는 아직, 밤이 삼키지 못한 작은 불씨가 있었다.'],
    ['02 / 세 개의 맹세','서로 다른 과거, 하나의 길.','아스트라는 검을 물려받았다. 세이르는 돌아오지 말았어야 할 미래를 보았다. 바르는 모든 기억을 잃고도 맹세 하나를 놓지 않았다.','세 사람은 서로를 믿지 않았다. 그러나 별이 남긴 조각이 같은 곳을 가리킬 때, 누구도 등을 돌리지 않았다. 폐허의 집행자와 성운 포식자 너머에 추락의 진실이 기다린다.'],
    ['03 / 마지막 성소','되찾을 것은 왕국이 아니다.','종말의 성체는 부서진 별의 심장을 품고 있다. 그것을 쓰러뜨리면 공허의 문은 닫히지만, 사라진 사람과 시간까지 돌아오지는 않는다.','이 원정의 끝에 약속된 영광은 없다. 다만 다음 아침, 누군가가 다시 자신의 이름을 말할 수 있다면. 세 사람에게는 그것으로 충분했다.']
  ];
  function chapter(index){const [label,title,...paragraphs]=chapters[index];document.getElementById('story-page').innerHTML=`<span class="brand">${label}</span><h3>${title}</h3>${paragraphs.map(p=>`<p>${p}</p>`).join('')}`;for(const button of document.querySelectorAll('[data-chapter]')){const selected=Number(button.dataset.chapter)===index;button.setAttribute('aria-selected',String(selected));button.tabIndex=selected?0:-1;}}
  for(const button of document.querySelectorAll('[data-chapter]')){button.onclick=()=>chapter(Number(button.dataset.chapter));button.onkeydown=e=>{if(['ArrowLeft','ArrowRight'].includes(e.key)){e.preventDefault();const index=(Number(button.dataset.chapter)+(e.key==='ArrowRight'?1:2))%3;chapter(index);document.querySelector(`[data-chapter="${index}"]`).focus();}};}
  chapter(0);
  const credits=document.querySelector('.credits-list');
  credits.insertAdjacentHTML('beforeend','<dt>이야기 · 세계관</dt><dd>폐허의 별 오리지널 세계관</dd><dt>개발 협업</dt><dd>OpenAI Codex</dd><dt>아트 제작</dt><dd>OpenAI 이미지 생성 · 런타임 3D 리그</dd><dt>음악 · 효과음</dt><dd>Web Audio 기반 오리지널 합성</dd>');
  const audio=document.querySelector('.audio-controls'),audioParent=audio.parentElement;
  let active=null,opener=null;
  function close(){
    if(!active)return;
    active.classList.add('hidden');active=null;
    audioParent.append(audio);opener?.focus();
  }
  function open(id,button){
    close();opener=button;active=document.getElementById(id);
    active.classList.remove('hidden');
    if(id==='settings')document.getElementById('settings-audio').append(audio);
    active.querySelector('button,input')?.focus();
    window.AstraAudio?.unlock();window.AstraAudio?.play('gem');
  }
  for(const button of document.querySelectorAll('[data-menu]'))button.onclick=()=>open(button.dataset.menu,button);
  for(const button of document.querySelectorAll('[data-close]'))button.onclick=close;
  for(const dialog of dialogs)dialog.addEventListener('click',e=>{if(e.target===dialog)close();});
  document.addEventListener('keydown',e=>{
    if(!active)return;
    if(e.code==='Escape'){e.stopImmediatePropagation();e.preventDefault();close();}
    if(e.key==='Tab'){
      const controls=[...active.querySelectorAll('button:not(:disabled),input:not(:disabled),a[href]')];
      const first=controls[0],last=controls.at(-1);
      if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}
      else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}
    }
  },true);
  const effects=document.getElementById('reduced-effects');
  try{effects.checked=localStorage.getItem('astra-reduced-effects')==='true';}catch{}
  window.AstraReducedEffects=effects.checked;
  effects.onchange=()=>{window.AstraReducedEffects=effects.checked;try{localStorage.setItem('astra-reduced-effects',String(effects.checked));}catch{}};
  document.getElementById('fullscreen').onclick=async()=>{
    try{if(document.fullscreenElement)await document.exitFullscreen();else await document.documentElement.requestFullscreen();}
    catch{document.getElementById('settings-status').textContent='이 브라우저에서는 전체 화면을 사용할 수 없습니다.';}
  };
  const start=document.getElementById('start'),training=document.getElementById('training-start');start.disabled=training.disabled=true;
  const timer=setTimeout(()=>{if(start.disabled)document.getElementById('save-status').textContent='게임 데이터를 불러오고 있습니다. 네트워크 연결을 확인해 주세요.';},15000);
  window.AstraShell={close,isOpen:()=>!!active,ready(){clearTimeout(timer);start.disabled=training.disabled=false;document.getElementById('save-status').textContent='';}};
})();
