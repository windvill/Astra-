window.AstraCharacters={
  astra:{name:'아스트라',hp:120,damage:18,speed:210,weapons:{sword:1},passive:{haste:1},lore:'하늘이 무너진 밤, 꺼지지 않은 검 한 자루를 물려받았다. 아스트라는 별을 되찾기보다, 아직 살아 있는 이들의 내일을 지키려 한다.'},
  seer:{name:'세이르',hp:90,damage:16,speed:225,weapons:{sword:1,bolt:1},passive:{},lore:'균열 너머에서 돌아온 예언자. 별의 추락을 예견하고도 막지 못했다. 이제 공허의 힘으로 자신이 본 마지막 미래에 맞선다.'},
  warden:{name:'바르',hp:160,damage:22,speed:185,weapons:{sword:2},passive:{},lore:'오래전 성소를 지키다 공허에 잠식된 수호자. 이름도 얼굴도 잊었지만, 누구도 이 문을 홀로 지나게 두지 않겠다는 맹세만은 남아 있다.'}
};
window.AstraSelectedCharacter='astra';
try{const id=localStorage.getItem('astra-character');if(window.AstraCharacters[id])window.AstraSelectedCharacter=id;}catch{}
window.createAstraParty=function(THREE,astra){
  const root=new THREE.Group();root.add(astra.root);
  const factory=window.createMonsterFactory(THREE),seer=factory({kind:'mage',r:14}),warden=factory({kind:'shield',r:14});
  root.add(seer.root,warden.root);seer.root.visible=warden.root.visible=false;
  let poseTime=0,lastTime=0;
  function animate(p,time){
    const id=p.character||'astra';astra.root.visible=id==='astra';seer.root.visible=id==='seer';warden.root.visible=id==='warden';
    if(id==='astra'){astra.animate(p,time);lastTime=time;return;}
    const rig=id==='seer'?seer:warden,dt=Math.max(0,Math.min(.05,time-lastTime));lastTime=time;
    if(p.moving||p.actionUntil>time)poseTime+=dt;
    const direction=p.actionAngle??p.aimAngle??Math.PI/4;
    const remaining=Math.max(0,(p.actionUntil||0)-time)/(p.actionDuration||.72)*.3;
    rig.animate({x:0,y:0,kind:id==='seer'?'mage':'shield',maxHp:p.maxHp,stationary:!p.moving,hit:p.invuln>0?.05:0,actionUntil:remaining>0?poseTime+remaining:0},{x:Math.cos(direction)*100,y:Math.sin(direction)*100},poseTime);
  }
  return {root,animate};
};
