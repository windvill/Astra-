window.astraMotionFrame=function(player,time){
  const attacking=(player.actionUntil||0)>time;
  const angle=attacking?player.actionAngle:(player.facingAngle??Math.PI/4);
  const dx=Math.cos(angle)-Math.sin(angle),dy=(Math.cos(angle)+Math.sin(angle))*.57;
  const side=Math.abs(dx)>Math.abs(dy);
  const row=side?1:dy>=0?0:3;
  let column=0;
  if(attacking){
    const duration=player.actionDuration||window.AstraSword.duration;
    const age=(1-(player.actionUntil-time)/duration)*window.AstraSword.duration;
    column=age<window.AstraSword.windup?3:age<window.AstraSword.strikeEnd?4:5;
  }else if(player.moving){column=[1,0,2,0][Math.floor(time*10)%4];}
  return {row,column,flip:side&&dx<0};
};
window.createAstraMotion=function(THREE,fallback){
  const root=new THREE.Group();root.add(fallback.root);
  const texture=new THREE.TextureLoader().load(window.AstraMotionImage,()=>{sprite.visible=true;fallback.root.visible=false;});
  texture.colorSpace=THREE.SRGBColorSpace;texture.generateMipmaps=false;
  texture.minFilter=THREE.LinearFilter;texture.magFilter=THREE.LinearFilter;
  const material=new THREE.SpriteMaterial({map:texture,transparent:true,depthWrite:false,toneMapped:false});
  // Key only strongly green pixels; silver armor and cyan magic remain opaque.
  material.onBeforeCompile=shader=>{
    shader.fragmentShader=shader.fragmentShader.replace('#include <map_fragment>',`#include <map_fragment>
      float excess=diffuseColor.g-max(diffuseColor.r,diffuseColor.b);
      diffuseColor.a*=1.0-smoothstep(0.12,0.45,excess);
      diffuseColor.g=min(diffuseColor.g,max(diffuseColor.r,diffuseColor.b)+0.08);
      if(diffuseColor.a<0.02) discard;`);
  };
  const sprite=new THREE.Sprite(material);sprite.visible=false;
  sprite.center.set(.5,.06);sprite.scale.set(38.5,38.5,1);root.add(sprite);
  function animate(player,time){
    if(!sprite.visible){fallback.animate(player,time);return;}
    const f=window.astraMotionFrame(player,time);
    texture.repeat.set(f.flip?-1/6:1/6,1/4);
    texture.offset.set((f.column+(f.flip?1:0))/6,1-(f.row+1)/4);
    material.color.set(player.invuln>0?'#ffb4a8':'#ffffff');
  }
  return {root,animate};
};
