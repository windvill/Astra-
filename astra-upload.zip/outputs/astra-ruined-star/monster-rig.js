window.createMonsterFactory = function(THREE) {
  const boxGeo=new THREE.BoxGeometry(1,1,1);
  const orbGeo=new THREE.IcosahedronGeometry(1,1);
  const coneGeo=new THREE.ConeGeometry(1,1,8);
  const colors={zombie:'#758079',worm:'#af668b',beast:'#ac7059',mage:'#535e9b',bomber:'#b99736',shield:'#597e73',assassin:'#765880',boss:'#7b4452'};
  return function(e) {
    const root=new THREE.Group(),body=new THREE.Group();root.add(body);
    const armor=new THREE.MeshStandardMaterial({color:colors[e.kind],metalness:.5,roughness:.6});
    const dark=new THREE.MeshStandardMaterial({color:'#20272d',roughness:.85});
    const glow=new THREE.MeshStandardMaterial({color:e.kind==='bomber'?'#ffc15c':'#b795ff',emissive:e.kind==='bomber'?'#f78723':'#794bce',emissiveIntensity:1.5});
    function shape(parent,geometry,mat,size,pos){const m=new THREE.Mesh(geometry,mat);m.scale.set(...size);m.position.set(...pos);parent.add(m);return m;}
    function joint(parent,x,y,z){const j=new THREE.Group();j.position.set(x,y,z);parent.add(j);return j;}
    const limbs=[],segments=[];
    const crawler=['worm','beast','bomber'].includes(e.kind);
    const caster=e.kind==='mage'||e.boss;
    let leftArm,rightArm,elbow,focus;
    if(crawler){
      shape(body,orbGeo,armor,[8,5,11],[0,7,0]);
      shape(body,orbGeo,dark,[5,4,5],[0,7,10]);
      for(const side of [-1,1]){
        shape(body,orbGeo,glow,[1,1,1],[side*2.5,8,14]);
        for(let i=0;i<3;i++){
          const leg=joint(body,side*6,7,6-i*6);
          shape(leg,boxGeo,armor,[7,1.8,2],[side*3,-1,0]);
          const knee=joint(leg,side*6,-1,0);
          shape(knee,coneGeo,dark,[2,6,2],[0,-3,0]);
          limbs.push({joint:leg,knee,phase:i*Math.PI*.7+(side===1?Math.PI:0)});
        }
      }
      if(e.kind==='worm')for(let i=0;i<4;i++){
        const segment=joint(body,0,6,-10-i*5);
        shape(segment,orbGeo,armor,[6-i,4-i*.4,5],[0,0,0]);segments.push(segment);
      }
      if(e.kind==='bomber')focus=shape(body,orbGeo,glow,[5,4,7],[0,11,0]);
      if(e.kind==='beast')for(const side of [-1,1])shape(body,coneGeo,armor,[2,8,2],[side*4,11,11]);
    }else{
      shape(body,boxGeo,armor,[9,10,5],[0,20,0]);
      shape(body,orbGeo,dark,[4,4.5,3.5],[0,29,0]);
      for(const side of [-1,1]){
        shape(body,orbGeo,glow,[.8,.65,.6],[side*1.4,29,3.4]);
        const hip=joint(body,side*2.5,15,0);
        shape(hip,boxGeo,dark,[3,6,3],[0,-3,0]);
        const knee=joint(hip,0,-6,0);
        shape(knee,boxGeo,armor,[3,7,3],[0,-3.5,0]);
        shape(knee,boxGeo,dark,[3,2,5],[0,-8,1]);
        limbs.push({joint:hip,knee,phase:side===1?Math.PI:0});
      }
      leftArm=joint(body,-6,23,0);rightArm=joint(body,6,23,0);
      for(const arm of [leftArm,rightArm]){
        shape(arm,orbGeo,armor,[3,2.5,3],[0,0,0]);
        shape(arm,boxGeo,dark,[2.5,5,2.5],[0,-3,0]);
        const forearm=joint(arm,0,-5,0);
        shape(forearm,boxGeo,armor,[2.5,5,3],[0,-2.5,0]);
        if(arm===rightArm)elbow=forearm;
      }
      if(caster){
        shape(body,coneGeo,armor,[8,20,7],[0,14,-1]);
        shape(body,coneGeo,armor,[5,9,4],[0,33,-1]);
        shape(elbow,boxGeo,dark,[1.5,24,1.5],[0,-3,3]);
        focus=shape(elbow,orbGeo,glow,[2.5,3.5,2.5],[0,10,3]);
      }else{
        shape(elbow,boxGeo,dark,[1.5,1.5,8],[0,-5,3]);
        shape(elbow,boxGeo,armor,[e.kind==='assassin'?2:5,1,13],[0,-5,13]);
      }
      if(e.kind==='shield')shape(leftArm,boxGeo,armor,[9,15,2],[0,-5,4]);
      if(e.boss)for(const side of [-1,1])shape(body,coneGeo,armor,[2,11,2],[side*4,36,0]);
    }
    const size=(e.r/14)*(e.elite?1.12:1);
    root.scale.setScalar(size);
    function animate(enemy,player,time){
      const angle=Math.atan2(player.x-enemy.x,player.y-enemy.y);
      root.rotation.y=angle;
      root.position.set(enemy.x,0,enemy.y);
      const remaining=Math.max(0,(enemy.actionUntil||0)-time);
      const action=remaining>0?Math.sin((1-remaining/.3)*Math.PI):0;
      const beat=time*(caster?5:enemy.kind==='worm'?14:10)+enemy.maxHp;
      const recoil=Math.max(0,enemy.hit||0)/.11;
      body.position.y=caster?3+Math.sin(time*3)*2:Math.abs(Math.sin(beat))*.6;
      body.position.z=action*(crawler?5:2)-recoil*2;
      body.rotation.x=(crawler?-.12:.06)+action*.14-recoil*.2;
      for(const leg of limbs){
        const stride=enemy.stationary?0:Math.sin(beat+leg.phase)*(1-action*.6);
        leg.joint.rotation.x=stride*(crawler?.35:.55);
        leg.joint.rotation.z=crawler?stride*.25:0;
        leg.knee.rotation.x=Math.max(0,-stride)*.7;
      }
      segments.forEach((segment,i)=>{segment.position.x=Math.sin(beat-i*.65)*2;segment.rotation.y=Math.sin(beat-i*.65)*.18;});
      if(rightArm){
        rightArm.rotation.x=action*(caster?-1.4:-2)+Math.sin(beat)*.15;
        rightArm.rotation.y=caster?0:action*.4;
        elbow.rotation.x=-.2-action*.45;
        leftArm.rotation.x=caster?-action*1.2:-Math.sin(beat)*.3;
      }
      if(focus){focus.rotation.y=time*2;glow.emissiveIntensity=1.5+action*3+(enemy.kind==='bomber'?Math.sin(time*10)*.5:0);}
      armor.emissive.set(recoil>0?'#a94233':'#000000');
    }
    return {root,animate,limbs,segments,dispose(){armor.dispose();dark.dispose();glow.dispose();}};
  };
};
