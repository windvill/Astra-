(() => {
  let context, master, music, effects, noise, nextBeat=0, beat=0;
  const recent={};
  const mute=document.getElementById('audio-mute'), volume=document.getElementById('audio-volume');
  let settings={muted:false,volume:45};
  try {
    const saved=JSON.parse(localStorage.getItem('astra-audio')||'null');
    if(saved)settings={muted:!!saved.muted,volume:Number.isFinite(saved.volume)?Math.max(0,Math.min(100,saved.volume)):45};
  } catch {}
  mute.checked=settings.muted;volume.value=settings.volume;
  function apply(){
    if(master)master.gain.setTargetAtTime(settings.muted?0:settings.volume/100,context.currentTime,.03);
    try{localStorage.setItem('astra-audio',JSON.stringify(settings));}catch{}
  }
  function unlock(){
    try {
      if(!context){
        const Audio=window.AudioContext||window.webkitAudioContext;
        if(!Audio)return;
        context=new Audio();master=context.createGain();music=context.createGain();effects=context.createGain();
        const limiter=context.createDynamicsCompressor();
        master.connect(limiter);limiter.connect(context.destination);
        const lowpass=context.createBiquadFilter();lowpass.type='lowpass';lowpass.frequency.value=1600;music.connect(lowpass);lowpass.connect(master);effects.connect(master);
        const reverb=context.createConvolver(),wet=context.createGain(),send=context.createGain();
        const impulse=context.createBuffer(2,Math.ceil(context.sampleRate*1.8),context.sampleRate);
        for(let ch=0;ch<2;ch++){const data=impulse.getChannelData(ch);for(let i=0;i<data.length;i++)data[i]=(Math.random()*2-1)*Math.pow(1-i/data.length,3)*.35;}
        reverb.buffer=impulse;wet.gain.value=.23;send.gain.value=.2;
        lowpass.connect(reverb);effects.connect(send);send.connect(reverb);reverb.connect(wet);wet.connect(master);
        music.gain.value=0;effects.gain.value=.65;
        noise=context.createBuffer(1,Math.ceil(context.sampleRate*.3),context.sampleRate);
        const samples=noise.getChannelData(0);
        for(let i=0;i<samples.length;i++)samples[i]=Math.random()*2-1;
        apply();
      }
      if(context.state==='suspended')context.resume().catch(()=>{});
    }catch{}
  }
  mute.onchange=()=>{settings.muted=mute.checked;unlock();apply();};
  volume.oninput=()=>{settings.volume=Number(volume.value);unlock();apply();};
  // Short envelopes and a master compressor keep overlapping combat sounds bounded.
  function tone(freq,end,length,level,type,bus,when=context.currentTime,attack=.012){
    const oscillator=context.createOscillator(), gain=context.createGain();
    oscillator.type=type;oscillator.frequency.setValueAtTime(freq,when);
    oscillator.frequency.exponentialRampToValueAtTime(Math.max(20,end),when+length);
    gain.gain.setValueAtTime(.0001,when);gain.gain.exponentialRampToValueAtTime(level,when+attack);
    gain.gain.exponentialRampToValueAtTime(.0001,when+length);
    oscillator.connect(gain);gain.connect(bus);oscillator.start(when);oscillator.stop(when+length+.02);
    oscillator.onended=()=>{oscillator.disconnect();gain.disconnect();};
  }
  function swish(){
    const source=context.createBufferSource(), filter=context.createBiquadFilter(), gain=context.createGain(), t=context.currentTime;
    source.buffer=noise;filter.type='bandpass';filter.Q.value=.7;
    filter.frequency.setValueAtTime(1700,t);filter.frequency.exponentialRampToValueAtTime(220,t+.16);
    gain.gain.setValueAtTime(.0001,t);gain.gain.exponentialRampToValueAtTime(.24,t+.025);gain.gain.exponentialRampToValueAtTime(.0001,t+.18);
    source.connect(filter);filter.connect(gain);gain.connect(effects);source.start();source.stop(t+.2);
    source.onended=()=>{source.disconnect();filter.disconnect();gain.disconnect();};
  }
  function play(name){
    if(!context||context.state!=='running'||settings.muted||settings.volume===0||document.hidden)return;
    const t=context.currentTime;
    if(t-(recent[name]??-10)<(name==='gem'?.09:.065))return;
    recent[name]=t;
    if(name==='swing')swish();
    else if(name==='hit'){tone(145,42,.14,.34,'triangle',effects);for(const n of [780,1294,2171])tone(n,n*.92,.22,.035,'sine',effects);}
    else if(name==='hurt'){tone(92,32,.3,.26,'triangle',effects);tone(137,58,.18,.09,'sine',effects);}
    else if(name==='gem'){tone(1046,1046,.3,.055,'sine',effects);tone(1569,1569,.2,.018,'sine',effects);}
    else if(name==='level')for(const [i,n] of [293.66,349.23,440,587.33].entries())tone(n,n,.85,.1,'sine',effects,t+i*.14);
    else if(name==='end')for(const [i,n] of [220,174.61,130.81].entries())tone(n,n,.55,.16,'triangle',effects,t+i*.16);
  }
  function tick(playing){
    if(!context)return;
    music.gain.setTargetAtTime(playing&&!document.hidden?.22:0,context.currentTime,.1);
    if(!playing||document.hidden||context.state!=='running'||settings.muted){nextBeat=context.currentTime;return;}
    const t=context.currentTime;
    if(nextBeat<t-.2)nextBeat=t;
    // Sparse minor-mode bells, sustained dark pads and low ritual drums.
    if(nextBeat<=t+.08){
      const root=[73.416,65.406,58.27,69.296][Math.floor(beat/16)%4];
      if(beat%8===0)for(const ratio of [1,1.1892,1.4983])tone(root*ratio,root*ratio*1.002,4.6,.12,'triangle',music,nextBeat,.7);
      if(beat%4===0)tone(72,29,.55,.24,'sine',music,nextBeat);
      if(beat%4===2){const n=root*[4,5.993,4.7568,4][Math.floor(beat/4)%4];tone(n,n,1.6,.075,'sine',music,nextBeat,.025);tone(n*2.71,n*2.71,.55,.015,'sine',music,nextBeat);}
      beat++;nextBeat+=.58;
    }
  }
  document.addEventListener('visibilitychange',()=>{if(document.hidden)tick(false);});
  window.AstraAudio={unlock,play,tick};
})();
