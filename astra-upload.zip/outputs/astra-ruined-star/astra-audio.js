(() => {
  let context, master, music, effects, noise, nextBeat=0, beat=0;
  const recent={};
  const mute=document.getElementById('audio-mute'), volume=document.getElementById('audio-volume');
  let settings={muted:false,volume:45};
  try {
    const saved=JSON.parse(localStorage.getItem('astra-audio')||'null');
    if(saved)settings={muted:!!saved.muted,volume:Number.isFinite(saved.volume)?Math.max(0,Math.min(100,saved.volume)):45};
  } catch {}
  mute.checked=settings.muted;volume.value=settings.volume;
  function apply(){
    if(master)master.gain.setTargetAtTime(settings.muted?0:settings.volume/100,context.currentTime,.03);
    try{localStorage.setItem('astra-audio',JSON.stringify(settings));}catch{}
  }
  function unlock(){
    try {
      if(!context){
        const Audio=window.AudioContext||window.webkitAudioContext;
        if(!Audio)return;
        context=new Audio();master=context.createGain();music=context.createGain();effects=context.createGain();
        const limiter=context.createDynamicsCompressor();
        master.connect(limiter);limiter.connect(context.destination);music.connect(master);effects.connect(master);
        music.gain.value=0;effects.gain.value=.65;
        noise=context.createBuffer(1,Math.ceil(context.sampleRate*.3),context.sampleRate);
        const samples=noise.getChannelData(0);
        for(let i=0;i<samples.length;i++)samples[i]=Math.random()*2-1;
        apply();
      }
      if(context.state==='suspended')context.resume().catch(()=>{});
    }catch{}
  }
  mute.onchange=()=>{settings.muted=mute.checked;unlock();apply();};
  volume.oninput=()=>{settings.volume=Number(volume.value);unlock();apply();};
  // Short envelopes and a master compressor keep overlapping combat sounds bounded.
  function tone(freq,end,length,level,type,bus,when=context.currentTime){
    const oscillator=context.createOscillator(), gain=context.createGain();
    oscillator.type=type;oscillator.frequency.setValueAtTime(freq,when);
    oscillator.frequency.exponentialRampToValueAtTime(Math.max(20,end),when+length);
    gain.gain.setValueAtTime(.0001,when);gain.gain.exponentialRampToValueAtTime(level,when+.012);
    gain.gain.exponentialRampToValueAtTime(.0001,when+length);
    oscillator.connect(gain);gain.connect(bus);oscillator.start(when);oscillator.stop(when+length+.02);
    oscillator.onended=()=>{oscillator.disconnect();gain.disconnect();};
  }
  function swish(){
    const source=context.createBufferSource(), filter=context.createBiquadFilter(), gain=context.createGain(), t=context.currentTime;
    source.buffer=noise;filter.type='bandpass';filter.Q.value=.7;
    filter.frequency.setValueAtTime(3000,t);filter.frequency.exponentialRampToValueAtTime(400,t+.16);
    gain.gain.setValueAtTime(.0001,t);gain.gain.exponentialRampToValueAtTime(.24,t+.025);gain.gain.exponentialRampToValueAtTime(.0001,t+.18);
    source.connect(filter);filter.connect(gain);gain.connect(effects);source.start();source.stop(t+.2);
    source.onended=()=>{source.disconnect();filter.disconnect();gain.disconnect();};
  }
  function play(name){
    if(!context||context.state!=='running'||settings.muted||settings.volume===0||document.hidden)return;
    const t=context.currentTime;
    if(t-(recent[name]??-10)<(name==='gem'?.09:.065))return;
    recent[name]=t;
    if(name==='swing')swish();
    else if(name==='hit'){tone(170,45,.13,.3,'triangle',effects);tone(1800,340,.065,.065,'square',effects);}
    else if(name==='hurt')tone(120,35,.28,.3,'sawtooth',effects);
    else if(name==='gem')tone(880,1400,.12,.09,'sine',effects);
    else if(name==='level')for(const [i,n] of [440,554.37,659.25,880].entries())tone(n,n,.45,.13,'sine',effects,t+i*.09);
    else if(name==='end')for(const [i,n] of [220,174.61,130.81].entries())tone(n,n,.55,.16,'triangle',effects,t+i*.16);
  }
  function tick(playing){
    if(!context)return;
    music.gain.setTargetAtTime(playing&&!document.hidden?.22:0,context.currentTime,.1);
    if(!playing||document.hidden||context.state!=='running'||settings.muted){nextBeat=context.currentTime;return;}
    const t=context.currentTime;
    if(nextBeat<t-.2)nextBeat=t;
    // Original minor-key ostinato with a slow bass progression.
    if(nextBeat<=t+.08){
      const root=[110,87.31,98,82.41][Math.floor(beat/16)%4];
      const ratio=[1,1.5,2,1.1892,1.5,2.3784,2,1.5][beat%8];
      tone(root*ratio*2,root*ratio*2,.55,.12,'sine',music,nextBeat);
      if(beat%4===0){tone(root,root,1.25,.22,'triangle',music,nextBeat);tone(65,30,.17,.22,'sine',music,nextBeat);}
      beat++;nextBeat+=.3;
    }
  }
  document.addEventListener('visibilitychange',()=>{if(document.hidden)tick(false);});
  window.AstraAudio={unlock,play,tick};
})();
