window.createAstraWorld=function(THREE,scene){
  const root=new THREE.Group();root.visible=false;scene.add(root);
  const chunks=new Map(),size=640;
  function random(seed){return ()=>{seed|=0;seed=seed+0x6d2b79f5|0;let n=Math.imul(seed^seed>>>15,1|seed);n^=n+Math.imul(n^n>>>7,61|n);return ((n^n>>>14)>>>0)/4294967296;};}
  const rng=random(107);
  const canvas=document.createElement('canvas');canvas.width=canvas.height=512;
  const ctx=canvas.getContext('2d');ctx.fillStyle='#242927';ctx.fillRect(0,0,512,512);
  // A seeded stone texture keeps streamed ground continuous and inexpensive.
  for(let row=0;row<8;row++)for(let col=-1;col<9;col++){
    const x=col*64+(row%2)*32,y=row*64,shade=48+Math.floor(rng()*22);
    ctx.fillStyle=`rgb(${shade},${shade+5},${shade+3})`;ctx.fillRect(x+2,y+2,60,60);
    ctx.strokeStyle='rgba(172,181,158,.18)';ctx.strokeRect(x+3,y+3,58,58);
    ctx.beginPath();ctx.moveTo(x+rng()*60,y);ctx.lineTo(x+20+rng()*20,y+25);ctx.lineTo(x+rng()*60,y+64);
    ctx.strokeStyle='rgba(12,19,18,.5)';ctx.stroke();
  }
  for(let i=0;i<14000;i++){
    ctx.fillStyle=rng()>.5?'rgba(190,193,174,.07)':'rgba(4,14,9,.12)';
    ctx.fillRect(rng()*512,rng()*512,1+rng()*3,1+rng()*3);
  }
  for(let i=0;i<180;i++){ctx.fillStyle='rgba(50,77,39,.22)';ctx.beginPath();ctx.ellipse(rng()*512,rng()*512,2+rng()*12,1+rng()*5,rng()*6,0,Math.PI*2);ctx.fill();}
  const texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;
  texture.wrapS=texture.wrapT=THREE.RepeatWrapping;texture.repeat.set(4,4);texture.anisotropy=4;
  const floorMat=new THREE.MeshStandardMaterial({map:texture,roughness:.96,color:'#bac1ab'});
  if(window.AstraFloorImage)new THREE.TextureLoader().load(window.AstraFloorImage,t=>{
    t.colorSpace=THREE.SRGBColorSpace;t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set(2,2);t.anisotropy=4;
    floorMat.map=t;floorMat.needsUpdate=true;texture.dispose();
  });
  const stone=new THREE.MeshStandardMaterial({color:'#747a70',roughness:.92});
  const rubbleMat=new THREE.MeshStandardMaterial({color:'#4d584d',roughness:1});
  const iron=new THREE.MeshStandardMaterial({color:'#272b28',roughness:.65,metalness:.7});
  const flameMat=new THREE.MeshBasicMaterial({color:'#ffbb63'});
  const floorGeo=new THREE.PlaneGeometry(size,size),rockGeo=new THREE.DodecahedronGeometry(1,0);
  const baseGeo=new THREE.BoxGeometry(36,9,36),shaftGeo=new THREE.CylinderGeometry(8,11,1,8),capGeo=new THREE.BoxGeometry(27,9,27);
  const bowlGeo=new THREE.CylinderGeometry(10,5,7,8),fireGeo=new THREE.OctahedronGeometry(7);
  function mesh(geo,mat,parent,x,y,z){const m=new THREE.Mesh(geo,mat);m.position.set(x,y,z);parent.add(m);return m;}
  function make(cx,cy){
    const group=new THREE.Group();group.position.set(cx*size,0,cy*size);
    const rand=random(Math.imul(cx,73856093)^Math.imul(cy,19349663)^511);
    const floor=mesh(floorGeo,floorMat,group,0,-1,0);floor.rotation.x=-Math.PI/2;floor.receiveShadow=true;
    const rocks=new THREE.InstancedMesh(rockGeo,rubbleMat,32),dummy=new THREE.Object3D();
    for(let i=0;i<32;i++){
      dummy.position.set((rand()-.5)*size,2,(rand()-.5)*size);dummy.scale.set(3+rand()*10,2+rand()*7,3+rand()*10);
      dummy.rotation.set(rand(),rand()*6,rand());dummy.updateMatrix();rocks.setMatrixAt(i,dummy.matrix);
    }
    rocks.castShadow=true;group.add(rocks);
    const flames=[];
    for(let i=0;i<3;i++){
      const x=(rand()-.5)*560,z=(rand()-.5)*560;
      if(Math.hypot(cx*size+x,cy*size+z)<90)continue;
      const height=30+rand()*70;
      mesh(baseGeo,stone,group,x,3,z);
      const shaft=mesh(shaftGeo,stone,group,x,height/2+7,z);shaft.scale.y=height;shaft.castShadow=true;
      if(i===0){
        mesh(capGeo,stone,group,x,height+10,z);mesh(bowlGeo,iron,group,x,height+17,z);
        const fire=mesh(fireGeo,flameMat,group,x,height+26,z);flames.push(fire);
      }
    }
    group.userData.flames=flames;root.add(group);return group;
  }
  // Only nearby chunks stay resident; coordinates regenerate the same landmarks.
  function update(player,time){
    root.visible=true;
    const cx=Math.floor((player.x+size/2)/size),cy=Math.floor((player.y+size/2)/size),wanted=new Set();
    for(let x=cx-2;x<=cx+2;x++)for(let y=cy-2;y<=cy+2;y++){
      const key=x+','+y;wanted.add(key);
      if(!chunks.has(key))chunks.set(key,make(x,y));
    }
    for(const [key,chunk] of chunks){
      if(!wanted.has(key)){root.remove(chunk);chunk.traverse(m=>{if(m.isInstancedMesh)m.dispose();});chunks.delete(key);continue;}
      for(const fire of chunk.userData.flames){fire.scale.set(.75,1.4+Math.sin(time*9+chunk.position.x)*.25,.75);fire.rotation.y=time*1.8;}
    }
  }
  return {update};
};
