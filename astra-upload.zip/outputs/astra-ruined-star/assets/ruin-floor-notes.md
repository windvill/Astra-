# Ruin Ground

Generated with the built-in image generation tool for this project.

Prompt: Seamless square top-down orthographic ground albedo for a dark fantasy sanctuary courtyard. Irregular weathered gray-green flagstones, chipped pale edges, cracks, moss, gravel and subtle carved celestial fragments. Neutral diffuse lighting, readable contrast. Continuous tileable floor without perspective, buildings, characters, text or UI.

The image is applied to streamed Three.js ground chunks; the procedural texture remains a loading fallback.
