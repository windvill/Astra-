# Astra Motion Atlas Draft

Generated with the built-in image generation tool using astra-knight.png as the character reference. Not connected to the game.

The 6-column, 4-row atlas contains opaque checkerboard pixels. Background extraction failed with usage_limit_reached. Do not treat its RGBA container as proof of transparency.

Requested columns: idle, left-foot step, right-foot step, overhead windup, downward strike, recovery.
Requested rows: down, left, right, up. Actual middle rows both face right; use verified side poses with horizontal mirroring for left, or regenerate.

Remaining work: obtain a transparent atlas, inspect cell alignment and strike poses, integrate directional frame selection while preserving 1.1 character scale and 30.8 melee range, and validate the rendered result.

Generation prompt: Create a production sprite atlas based on the referenced Astra character, preserving white hair, silver armor, navy star-pattern cloak and cyan sword. Genuine transparent alpha background. Exact 6 columns by 4 rows regular grid, 24 separate full-body figures. Each figure centered horizontally with aligned feet, sword contained in its cell. Slightly elevated isometric view. Rows: down/front, left, right, up/back. Columns: idle, left-foot step, right-foot step, overhead windup, downward strike, recovery. Consistent proportions and costume; no overlap, labels, scenery or borders.

Pending edit prompt: Remove all white/gray checkerboard and replace with genuinely transparent PNG alpha. Preserve canvas dimensions, 6x4 arrangement, character poses, positions, scale, details, weapons and colors. No redraw, rearrangement, crop, new background, shadows or labels.
