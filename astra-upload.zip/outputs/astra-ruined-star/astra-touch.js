(() => {
  const layer=document.createElement('div');layer.id='touch-controls';layer.hidden=true;
  layer.innerHTML='<div class="touch-stick" data-stick="move" role="group" aria-label="이동 및 공격 방향 조이스틱"><span class="stick-symbol">✥</span><span class="stick-knob"></span></div>';
  document.body.append(layer);
  const state={x:0,y:0,enabled:false};
  const sticks=[];
  const coarse=matchMedia('(any-pointer: coarse)');
  function reset(){state.x=state.y=0;for(const stick of sticks){if(stick.id!==null&&stick.el.hasPointerCapture(stick.id))stick.el.releasePointerCapture(stick.id);stick.id=null;stick.knob.style.transform='translate(0px,0px)';}}
  for(const el of layer.children){
    const stick={el,knob:el.querySelector('.stick-knob'),id:null};sticks.push(stick);
    function move(e){
      if(e.pointerId!==stick.id)return;
      const r=el.getBoundingClientRect(),dx=e.clientX-r.left-r.width/2,dy=e.clientY-r.top-r.height/2;
      const distance=Math.hypot(dx,dy),radius=r.width*.32,scale=Math.min(1,radius/(distance||1));
      const x=distance<7?0:dx*scale/radius,y=distance<7?0:dy*scale/radius;
      stick.knob.style.transform=`translate(${x*radius}px,${y*radius}px)`;
      state.x=x;state.y=y;
      e.preventDefault();
    }
    el.addEventListener('pointerdown',e=>{if(!state.enabled||stick.id!==null)return;stick.id=e.pointerId;el.setPointerCapture(e.pointerId);move(e);});
    el.addEventListener('pointermove',move);
    function end(e){if(e.pointerId!==stick.id)return;stick.id=null;stick.knob.style.transform='translate(0px,0px)';if(el.dataset.stick==='move')state.x=state.y=0;}
    el.addEventListener('pointerup',end);el.addEventListener('pointercancel',end);el.addEventListener('lostpointercapture',end);
  }
  addEventListener('blur',reset);addEventListener('resize',reset);
  document.addEventListener('visibilitychange',()=>{if(document.hidden)reset();});
  window.AstraTouch={state,reset,enable(active){const enabled=!!active&&coarse.matches;if(enabled===state.enabled)return;state.enabled=enabled;layer.hidden=!enabled;if(!enabled)reset();},restart:reset};
})();
