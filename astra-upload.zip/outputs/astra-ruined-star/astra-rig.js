/* Articulated character: local +Z is forward; joints use world-scale units. */
window.createAstraRig = function (THREE) {
  const root = new THREE.Group();
  root.scale.set(1.1,1.1,1.1);
  const torso = new THREE.Group();
  root.add(torso);
  const material = (color, metalness = .25) => new THREE.MeshStandardMaterial({color, metalness, roughness:.5});
  const silver = material('#bdc9d5', .7), dark = material('#273c53');
  const cloth = material('#184c67'), skin = material('#e6c0a8', 0), hair = material('#e5e7ee');
  const light = new THREE.MeshStandardMaterial({color:'#c8faff',emissive:'#52dcff',emissiveIntensity:2});
  function box(parent, mat, size, pos) {
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(...size), mat);
    mesh.position.set(...pos); mesh.castShadow = true; parent.add(mesh); return mesh;
  }
  function joint(parent, x, y, z) {
    const node = new THREE.Group(); node.position.set(x,y,z); parent.add(node); return node;
  }
  box(torso,dark,[6.5,8,3.8],[0,20,0]);
  box(torso,silver,[6.8,5,1.2],[0,21,2]);
  box(torso,silver,[7.2,1.2,4.2],[0,16,0]);
  const core = new THREE.Mesh(new THREE.OctahedronGeometry(1.2),light);
  core.position.set(0,22,2.8); torso.add(core);
  const head = joint(torso,0,27,0);
  const face = new THREE.Mesh(new THREE.SphereGeometry(2.7,12,10),skin);
  face.scale.set(.85,1,.88);head.add(face);
  box(head,hair,[4.5,1.6,4.5],[0,2,0]);
  box(head,hair,[4.5,3,1.3],[0,.6,-2]);
  box(head,dark,[.55,.35,.25],[-.85,.3,2.35]);
  box(head,dark,[.55,.35,.25],[.85,.3,2.35]);
  const ponytail=joint(head,0,1.5,-2);
  box(ponytail,hair,[1.7,6,1.6],[0,-2.5,-1]);
  const cape=joint(torso,0,24,-2.5);
  box(cape,cloth,[7,.7,3.5],[0,0,-.8]);
  const capeBottom=joint(cape,0,-5,-1);
  box(cape,cloth,[7,7,.7],[0,-3,-1]);
  box(capeBottom,cloth,[9,8,.65],[0,-4,-1]);
  function leg(x) {
    const hip=joint(root,x,15,0);
    box(hip,dark,[2.4,6,2.5],[0,-3,0]);
    const knee=joint(hip,0,-6,0);
    box(knee,silver,[2.2,6,2.5],[0,-3,0]);
    box(knee,dark,[2.6,2,4],[0,-7,1]);
    return {hip,knee};
  }
  function arm(x) {
    const shoulder=joint(torso,x,23,0);
    box(shoulder,silver,[3.6,2.2,4],[0,0,0]);
    box(shoulder,dark,[1.8,4,2],[0,-2.5,0]);
    const elbow=joint(shoulder,0,-4.5,0);
    box(elbow,silver,[1.9,4,2.1],[0,-2,0]);
    const hand=joint(elbow,0,-4,0);
    box(hand,dark,[1.8,1.8,1.8],[0,0,0]);
    return {shoulder,elbow,hand};
  }
  const leftLeg=leg(-2.1),rightLeg=leg(2.1),leftArm=arm(-4.4),rightArm=arm(4.4);
  const weapon=joint(rightArm.hand,0,0,0);
  box(weapon,dark,[1,1,3],[0,0,1]);
  box(weapon,silver,[5,.7,.8],[0,0,3]);
  const blade=box(weapon,light,[.85,.45,17],[0,0,12]);
  let facing=0,lastTime=null;
  function animate(player,time) {
    const delta=lastTime===null?0:Math.max(0,Math.min(.05,time-lastTime));lastTime=time;
    const attacking=(player.actionUntil||0)>time;
    const desired=Math.PI/2-(attacking?player.actionAngle:(player.facingAngle??Math.PI/2));
    const turn=Math.atan2(Math.sin(desired-facing),Math.cos(desired-facing));
    facing+=turn*(attacking?1:1-Math.exp(-delta*18));
    root.rotation.y=facing;
    const stride=player.moving?Math.sin(time*15):0;
    leftLeg.hip.rotation.x=stride*.65;rightLeg.hip.rotation.x=-stride*.65;
    leftLeg.knee.rotation.x=Math.max(0,-stride)*.9;
    rightLeg.knee.rotation.x=Math.max(0,stride)*.9;
    torso.position.y=player.moving?Math.abs(stride)*.6:Math.sin(time*2)*.15;
    leftArm.shoulder.rotation.x=-stride*.35;
    leftArm.elbow.rotation.x=0;
    rightArm.shoulder.rotation.x=stride*.35;
    rightArm.shoulder.rotation.y=0;rightArm.elbow.rotation.x=-.25;
    weapon.rotation.x=.25;
    torso.rotation.y=0;torso.rotation.x=0;
    if(attacking){
      const timing=window.AstraSword;
      const age=timing.duration-(player.actionUntil-time);
      const smooth=t=>{t=Math.max(0,Math.min(1,t));return t*t*(3-2*t);};
      let raise,cut;
      if(age<timing.windup){
        raise=smooth(age/timing.windup);cut=0;
      }else if(age<=timing.strikeEnd){
        raise=1;cut=smooth(timing.strike(age));
      }else{
        raise=1-smooth((age-timing.strikeEnd)/(timing.duration-timing.strikeEnd));
        cut=1;
      }
      torso.rotation.x=(-.06+.18*cut)*raise;
      rightArm.shoulder.rotation.x=(-2.65+1.75*cut)*raise;
      rightArm.shoulder.rotation.y=0;
      rightArm.elbow.rotation.x=-.25+(-.6+.45*cut)*raise;
      // Pitch the blade in the forward vertical plane: overhead to ground.
      const bladePitch=(-1.35+2.15*cut)*raise;
      weapon.rotation.x=bladePitch-rightArm.shoulder.rotation.x-rightArm.elbow.rotation.x-torso.rotation.x;
      leftArm.elbow.rotation.x=-.3*raise;
    }
    cape.rotation.x=(player.moving?-.3:-.08)+Math.sin(time*7)*.06;
    capeBottom.rotation.x=Math.sin(time*7-.5)*.13;
    ponytail.rotation.x=Math.sin(time*9)*.15;
    silver.emissive.set(player.invuln>0?'#792018':'#000000');
  }
  return {root,animate,joints:{leftLeg,rightLeg,leftArm,rightArm,cape,head},blade};
};
