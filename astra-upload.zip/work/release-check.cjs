const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const html=fs.readFileSync('outputs/astra-ruined-star/index.html','utf8');
const scripts=[...html.matchAll(/<script([^>]*)>([\s\S]*?)<\/script>/g)];
function fixture(saved='null',failSave=false){
  const elements=new Map(),events={},writes=[];let scheduled=0,cancelled=0;
  const element=id=>{
    if(!elements.has(id)){const classes=new Set();elements.set(id,{classList:{add:x=>classes.add(x),remove:x=>classes.delete(x),contains:x=>classes.has(x)},style:{},dataset:{},children:[],append(child){this.children.push(child);},focus(){},querySelector(){return null;},addEventListener(){},getContext:()=>new Proxy({},{get:()=>()=>{}})});}
    return elements.get(id);
  };
  const c={innerWidth:1280,innerHeight:720,devicePixelRatio:1,document:{body:element('body'),querySelector:element,getElementById:element,createElement:()=>element(Math.random()),addEventListener(){}},localStorage:{getItem:()=>saved,setItem:(k,v)=>{if(failSave)throw Error('blocked');writes.push(v);}},addEventListener:(n,f)=>events[n]=f,requestAnimationFrame(){return ++scheduled;},cancelAnimationFrame(){cancelled++;},setTimeout(){},performance:{now:()=>0}};c.window=c;vm.createContext(c);vm.runInContext(scripts[0][2],c);
  const injected='window.test={startRun,finish,update,choose,gainXp,openChoices,spawnBoss,damageEnemy,updateGems,updateWeapons,updateZones,updateEnemies,saveMeta,buy,player:()=>player,enemies,gems,zones,meta,setTime:t=>elapsed=t,state:()=>({running,paused,choiceOpen,pendingChoices}),togglePause,resetPlayer:()=>{player.hp=player.maxHp;player.invuln=10000;}};';
  vm.runInContext(scripts.at(-1)[2].replace('renderShop(); draw();',injected+'renderShop();draw();'),c);
  vm.runInContext(fs.readFileSync('outputs/astra-ruined-star/astra-characters.js','utf8'),c);
  return {c,game:c.test,e:element,counts:()=>({scheduled,cancelled}),writes};
}
const f=fixture('{broken'),g=f.game;
assert.equal(g.meta.shards,0,'corrupted save falls back safely');g.meta.tutorial=1;g.startRun();g.startRun();assert.equal(f.counts().scheduled,1,'double start cannot duplicate loop');
g.gainXp(1000);const levels=g.player().level-1;assert(levels>2);let choices=0;while(g.state().choiceOpen&&choices<100){g.choose(0);choices++;}assert.equal(choices,levels,'every earned level receives a choice');
g.gems.push({x:g.player().x,y:g.player().y,xp:1});g.updateGems(.05);assert.equal(g.gems.length,0,'coincident gem collected without NaN');
g.togglePause();assert(g.state().paused);g.togglePause();assert(!g.state().paused);
g.setTime(900);g.spawnBoss(300);g.damageEnemy(g.enemies.at(-1),1e9,'#fff');assert(g.state().running,'old boss cannot finish final encounter');
g.spawnBoss(900);g.damageEnemy(g.enemies.at(-1),1e9,'#fff');assert(!g.state().running,'final boss clears expedition');
assert.equal(g.meta.runs,1);const shards=g.meta.shards;g.finish(true);assert.equal(g.meta.shards,shards,'reward applied once');
g.startRun();assert(g.state().running);assert.equal(g.player().level,1);assert.equal(g.state().pendingChoices,0);
Object.assign(g.player().weapons,{sword:8,bolt:8,meteor:8,lightning:8,blackhole:8,nebula:8});
for(const id of ['fire','pierce','haste','area','duration','magnet','crit','vitality'])g.player().passive[id]=5;
g.gainXp(25);assert.equal(JSON.parse(f.e('levelup').dataset.picks)[0].type,'heal','maxed build has valid recovery choice');g.choose(0);assert(!g.state().choiceOpen);
const blocked=fixture('null',true);blocked.game.saveMeta();assert(blocked.e('save-status').textContent.includes('저장'),'storage failure communicated');
const sim=fixture().game;sim.meta.tutorial=1;sim.startRun();Object.assign(sim.player().weapons,{bolt:2,meteor:2,lightning:2,blackhole:1,nebula:1});
for(let i=0;i<1800;i++){sim.resetPlayer();if(sim.state().choiceOpen)sim.choose(0);else sim.update(.05);}
assert(sim.enemies.length<=240);assert(sim.gems.length<=600);assert(sim.zones.filter(z=>z.type==='nebula').length<=1);assert(sim.player().kills>0,'simulated combat produces kills');
assert(Number.isFinite(sim.player().hp));console.log('Release checks passed: corrupt/blocked saves, single RAF, queued levels, pickup, pause/retry, final boss, reward idempotence, maxed build and 90s combat simulation.');
const training=fixture(),tg=training.game;tg.startRun();assert.equal(training.e('tutorial-title').textContent,'첫 번째 별의 표식');
const marker=training.c.AstraView.unproject(120*2*training.c.AstraView.span(1280)/720,0);tg.player().x=marker.x;tg.player().y=marker.y;tg.update(.01);assert.equal(tg.enemies.length,1);
tg.damageEnemy(tg.enemies[0],1000,'#fff');tg.update(.01);
assert.equal(training.e('tutorial-title').textContent,'돌아오는 별의 조각');
tg.player().x=tg.gems[0].x;tg.player().y=tg.gems[0].y;tg.update(.01);assert(tg.state().choiceOpen);
tg.choose(0);tg.update(.01);assert.equal(training.e('tutorial-title').textContent,'수련 완료');
training.e('#tutorial-skip').onclick();assert.equal(tg.meta.tutorial,1);assert.equal(tg.meta.runs,0);assert.equal(tg.meta.shards,0);assert.equal(tg.player().level,1);
tg.finish(false);training.c.AstraSelectedCharacter='seer';tg.startRun();assert.equal(tg.player().maxHp,90);assert.equal(tg.player().weapons.bolt,1);assert.equal(tg.player().character,'seer');
tg.finish(false);training.c.AstraSelectedCharacter='warden';tg.startRun();assert.equal(tg.player().maxHp,160);assert.equal(tg.player().weapons.sword,2);assert.equal(tg.player().damage,22);
console.log('Tutorial movement/kill/XP/blessing/completion and three character profiles passed.');
tg.finish(false);tg.startRun(true);tg.player().weapons={};training.c.AstraTouch={state:{enabled:true,x:0,y:0}};
const target={x:tg.player().x+30,y:tg.player().y+10,dead:false,hp:10000};
tg.enemies.push({x:1000,y:1000,dead:false,hp:10000},target,{x:0,y:1,dead:true});
tg.update(0);assert.equal(tg.player().aimAngle,Math.atan2(10,30),'nearest living enemy selected');
Object.assign(training.c.AstraTouch.state,{x:-1,y:0});tg.update(.01);
assert.equal(tg.player().aimAngle,Math.atan2(target.y-tg.player().y,target.x-tg.player().x),'aim independent of movement');
target.dead=true;tg.update(0);assert.equal(tg.player().aimAngle,Math.atan2(1000-tg.player().y,1000-tg.player().x),'retarget after death');
const angle=tg.player().aimAngle;tg.enemies.length=0;tg.update(0);assert.equal(tg.player().aimAngle,angle,'empty arena retains direction');
console.log('Mobile nearest-enemy targeting, movement independence, retargeting and empty arena passed.');
