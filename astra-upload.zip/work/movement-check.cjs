const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const html = fs.readFileSync('outputs/astra-ruined-star/index.html', 'utf8');
const scripts = [...html.matchAll(/<script([^>]*)>([\s\S]*?)<\/script>/g)];
for (const [, , source] of scripts) new Function(source.replace(/^\s*import .*;$/m, ''));
const handlers = {};
const elements = new Map();
function element(id) {
  if (!elements.has(id)) elements.set(id, {
    classList: { add() {}, remove() {} }, style: {}, dataset: {},
    append() {}, focus() {}, addEventListener() {},
    getContext: () => new Proxy({}, { get: () => () => {} })
  });
  return elements.get(id);
}
const sandbox = {
  innerWidth: 1280, innerHeight: 720, devicePixelRatio: 1,
  document: { querySelector: element, getElementById: element, createElement: element, addEventListener() {} },
  localStorage: { getItem: () => null, setItem() {} },
  addEventListener: (name, callback) => handlers[name] = callback,
  requestAnimationFrame() {}, setTimeout() {}, performance: { now: () => 0 }
};
sandbox.window = sandbox;
vm.createContext(sandbox);
vm.runInContext(scripts[0][2], sandbox);
const game = scripts.at(-1)[2].replace('renderShop(); draw();',
  'window.check = { startRun, updatePlayer, position: () => ({...player}), resize, enemies, slashes, particles, slash, drawSlash, updateEnemies, shootEnemy, projectiles, updateParticles };');
vm.runInContext(game, sandbox);
for (const [width, height] of [[1280,720], [390,844]]) {
  sandbox.innerWidth=width; sandbox.innerHeight=height;
  sandbox.check.resize(); sandbox.check.startRun();
  const view=sandbox.AstraView;
  const screen = () => { const p=sandbox.check.position(); return view.project(p.x,p.y,width,height); };
  const initial=screen(); let prevented=false;
  handlers.keydown({ code:'KeyD', key:'ㅇ', preventDefault(){prevented=true;} });
  sandbox.check.updatePlayer(.2);
  assert(prevented, 'movement prevents page scrolling');
  assert(screen().x>initial.x, 'Korean-layout D visibly moves right');
  assert(Math.abs(screen().y-initial.y)<.001, 'D follows screen horizontal axis');
  handlers.keyup({code:'KeyD'});
  const stopped=screen(); sandbox.check.updatePlayer(.2);
  assert.deepEqual(screen(),stopped, 'keyup stops movement');
  handlers.keydown({code:'KeyW',key:'ㅈ',preventDefault(){}});
  sandbox.check.updatePlayer(.2);
  assert(screen().y<stopped.y, 'Korean-layout W visibly moves up');
  handlers.blur();
  const unfocused=screen(); sandbox.check.updatePlayer(.2);
  assert.deepEqual(screen(),unfocused, 'blur clears held keys');
  handlers.keydown({code:'ArrowRight',preventDefault(){}});
  for(let i=0;i<1000;i++)sandbox.check.updatePlayer(.05);
  assert(screen().x<width && screen().x>0, 'arena boundary keeps player on screen');
  handlers.blur();
  const spriteHeight=31.5*height/(2*view.span(width));
  assert(spriteHeight<100, 'sprite stays under 100 CSS pixels');
  console.log(`${width}x${height}: input, screen motion, release, blur, boundary pass; sprite ${spriteHeight.toFixed(1)}px`);
}
const moduleCode=scripts.find(s=>s[1].includes('module'))[2];
assert(!moduleCode.includes('camera.position.set(p.x'), 'camera must not cancel player movement');
console.log('All script syntax and fixed-camera checks passed.');
const gameCheck=sandbox.check;
gameCheck.startRun();
const foe={x:25,y:0,r:14,hp:100,maxHp:100,hit:0,attack:0,shoot:3,blink:3,speed:0,damage:10,kind:'zombie',color:'#fff'};
gameCheck.enemies.push(foe);
const farFoe={...foe,x:60};gameCheck.enemies.push(farFoe);
gameCheck.slash(0,30.8,20);
assert.equal(foe.hp,100,'swing cannot hit before blade reaches the target');
gameCheck.updateParticles(.06);
assert.equal(foe.hp,100,'windup does not cause damage');
gameCheck.updateParticles(.15);
assert.equal(foe.hp,80,'blade hits as it sweeps through the target');
assert(gameCheck.position().actionUntil>0,'slash triggers player action');
assert(gameCheck.particles.length>0,'hit produces particles');
const hp=foe.hp;
gameCheck.drawSlash(gameCheck.slashes[0]);
gameCheck.drawSlash(gameCheck.slashes[0]);
assert.equal(foe.hp,hp,'drawing during pause cannot apply extra damage');
foe.x=10;
gameCheck.updateEnemies(.01);
assert(foe.actionUntil>0,'contact attack triggers monster action');
assert(gameCheck.position().hp<120,'contact attack does damage');
gameCheck.shootEnemy(foe);
assert(gameCheck.projectiles.length>0,'casting action creates projectile');
assert.equal(gameCheck.slashes[0].x,0,'slash stays anchored at attack origin');
console.log('Action triggers, damage timing, cast projectile, hit particles and render-only slash checks passed.');
gameCheck.updateParticles(.25);
assert.equal(foe.hp,80,'same swing cannot hit target twice');
assert.equal(gameCheck.slashes.length,0,'swing expires at end of arc');
assert.equal(farFoe.hp,100,'old large-character range cannot hit distant enemy');
assert(moduleCode.includes('astraRig.animate(p,state.time)'), 'articulated character receives live player state');
console.log('Half-size sprite and single-hit directional sweep passed.');
