const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
class Vector{constructor(){this.x=this.y=this.z=0;}set(x,y,z){Object.assign(this,{x,y,z});}setScalar(v){this.set(v,v,v);}}
class Node{constructor(){this.position=new Vector();this.rotation=new Vector();this.scale=new Vector();this.children=[];}add(...children){this.children.push(...children);}}
class Material{constructor(){this.emissive={set(){}};}dispose(){this.disposed=true;}}
class Mesh extends Node{constructor(g,m){super();this.material=m;}}
const THREE={Group:Node,Mesh,MeshStandardMaterial:Material,BoxGeometry:class{},IcosahedronGeometry:class{},ConeGeometry:class{}};
const context={window:{}};vm.createContext(context);
vm.runInContext(fs.readFileSync('outputs/astra-ruined-star/monster-rig.js','utf8'),context);
const create=context.window.createMonsterFactory(THREE);
const pose=n=>JSON.stringify({p:n.position,r:n.rotation,c:n.children.map(pose)});
for(const kind of ['zombie','worm','beast','mage','bomber','shield','assassin','boss']){
  const e={kind,r:14,x:10,y:20,hp:100,maxHp:100,hit:0,boss:kind==='boss'};
  const rig=create(e),p={x:100,y:20};
  rig.animate(e,p,1);
  assert(Math.abs(rig.root.rotation.y-Math.PI/2)<1e-6,'faces target');
  const walking=pose(rig.root);rig.animate(e,p,1.1);
  assert.notEqual(pose(rig.root),walking,'joints animate over time');
  const idle=pose(rig.root);e.actionUntil=1.25;rig.animate(e,p,1.1);
  assert.notEqual(pose(rig.root),idle,'attack changes pose');
  const attack=pose(rig.root);rig.animate(e,p,1.1);
  assert.equal(pose(rig.root),attack,'paused time freezes pose');
  e.hit=.11;rig.animate(e,p,1.1);
  assert.notEqual(pose(rig.root),attack,'hit recoil changes pose');
  rig.dispose();console.log(kind+': facing, gait, attack, pause, recoil, disposal passed');
}
