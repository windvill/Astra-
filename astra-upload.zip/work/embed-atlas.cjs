const fs=require('node:fs');
const base='outputs/astra-ruined-star/assets/';
const data=fs.readFileSync(base+'astra-motion-keyed.png').toString('base64');
fs.writeFileSync(base+'astra-motion-data.js','window.AstraMotionImage = '+JSON.stringify('data:image/png;base64,'+data)+';\n');
