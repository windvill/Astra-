const fs=require('node:fs');
const dir='outputs/astra-ruined-star/assets/';
fs.writeFileSync(dir+'ruin-floor-data.js','window.AstraFloorImage='+JSON.stringify('data:image/png;base64,'+fs.readFileSync(dir+'ruin-floor.png').toString('base64'))+';\n');
