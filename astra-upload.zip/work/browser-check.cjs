const fs=require('node:fs'),assert=require('node:assert/strict');
const deps='C:/Users/gs112/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/';
const {chromium}=require(deps+'playwright'),{PNG}=require(deps+'pngjs');
(async()=>{
  const browser=await chromium.launch({channel:'msedge',headless:true,args:['--autoplay-policy=no-user-gesture-required']});
  try{
    fs.mkdirSync('work/qa',{recursive:true});
    for(const [width,height] of [[1280,720],[390,844]]){
      const page=await browser.newPage({viewport:{width,height}}),errors=[];
      page.on('pageerror',e=>errors.push(e.message));
      await page.addInitScript(()=>{
        const Native=window.AudioContext;
        window.__audio={voices:0,context:null};
        window.AudioContext=class extends Native{
          constructor(...args){super(...args);window.__audio.context=this;}
          createOscillator(){window.__audio.voices++;return super.createOscillator();}
        };
      });
      await page.goto('https://astra-pi-blond.vercel.app/',{waitUntil:'networkidle'});
      await page.waitForFunction(()=>window.createAstraWorld&&window.Astra3D?.ready);
      await page.getByRole('button',{name:'원정 시작',exact:false}).waitFor({state:'visible'});
      await page.screenshot({path:`work/qa/title-${width}.png`});
      await page.getByRole('button',{name:'성소 강화',exact:true}).click();
      assert(await page.getByRole('dialog',{name:'꺼지지 않는 힘'}).isVisible());
      await page.screenshot({path:`work/qa/sanctuary-${width}.png`});
      await page.keyboard.press('Escape');
      await page.locator('#menu').getByRole('button',{name:'설정',exact:true}).click();
      await page.getByRole('checkbox',{name:'간소화 효과'}).check();
      await page.screenshot({path:`work/qa/settings-${width}.png`});
      await page.keyboard.press('Escape');
      await page.getByRole('button',{name:'원정 시작',exact:false}).click();
      await page.mouse.move(width*.8,height*.4);await page.waitForTimeout(1800);
      const before=await page.screenshot({path:`work/qa/map-${width}-before.png`});
      const origin=await page.evaluate(()=>({x:AstraView.cameraX,y:AstraView.cameraY}));
      await page.keyboard.down('KeyD');await page.waitForTimeout(5000);await page.keyboard.up('KeyD');
      const after=await page.screenshot({path:`work/qa/map-${width}-after.png`});
      const state=await page.evaluate(()=>({x:AstraView.cameraX,y:AstraView.cameraY,reach:AstraSword.reach,voices:__audio.voices,audio:__audio.context?.state}));
      assert(Math.hypot(state.x-origin.x,state.y-origin.y)>250,'world scrolls with movement');
      assert.equal(state.reach,65);assert(state.voices>5);assert.equal(state.audio,'running');
      const a=PNG.sync.read(before),b=PNG.sync.read(after);let changed=0,bright=0,green=0;
      for(let y=height*.2|0;y<height*.8;y++)for(let x=width*.15|0;x<width*.85;x++){
        const i=(y*width+x)*4;
        if(Math.abs(a.data[i]-b.data[i])+Math.abs(a.data[i+1]-b.data[i+1])+Math.abs(a.data[i+2]-b.data[i+2])>35)changed++;
        if(b.data[i]+b.data[i+1]+b.data[i+2]>70)bright++;
        if(Math.abs(x-width/2)<29&&y<height/2&&y>height/2-90&&b.data[i+1]>b.data[i]*1.3&&b.data[i+1]>150)green++;
      }
      assert(changed>width*height*.03,'scene visibly moves');assert(bright>width*height*.1,'3D canvas is nonblank');assert(green>25,'overhead health bar renders');
      await page.getByRole('checkbox',{name:'음소거',exact:true}).check();
      await page.getByRole('button',{name:'일시정지',exact:true}).click();
      const frozen=await page.evaluate(()=>({x:AstraView.cameraX,y:AstraView.cameraY}));
      await page.keyboard.down('KeyD');await page.waitForTimeout(350);await page.keyboard.up('KeyD');
      assert.deepEqual(await page.evaluate(()=>({x:AstraView.cameraX,y:AstraView.cameraY})),frozen);
      await page.screenshot({path:`work/qa/pause-${width}.png`});
      await page.getByRole('button',{name:'원정 종료',exact:true}).click();
      assert(await page.getByRole('button',{name:'다시 도전',exact:true}).isVisible());
      await page.screenshot({path:`work/qa/result-${width}.png`});
      await page.getByRole('button',{name:'다시 도전',exact:true}).click();
      await page.waitForTimeout(400);
      assert(await page.getByRole('button',{name:'일시정지',exact:true}).isVisible());
      assert.deepEqual(errors,[]);console.log(JSON.stringify({width,height,...state,changed,bright,green,errors}));await page.close();
    }
  }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
