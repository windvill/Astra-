const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const c={window:{AstraSword:{duration:.44,windup:.12,strikeEnd:.26}}};vm.createContext(c);
vm.runInContext(fs.readFileSync('outputs/astra-ruined-star/astra-motion.js','utf8'),c);
const frame=c.window.astraMotionFrame;
assert.equal(frame({facingAngle:Math.PI/4},0).row,0);
assert.equal(frame({facingAngle:-3*Math.PI/4},0).row,3);
assert.equal(frame({facingAngle:-Math.PI/4},0).flip,false);
assert.equal(frame({facingAngle:3*Math.PI/4},0).flip,true);
assert.notEqual(frame({moving:true},.01).column,frame({moving:true},.21).column);
for(const [time,column] of [[.05,3],[.2,4],[.35,5]])assert.equal(frame({actionUntil:.44,actionAngle:0},time).column,column);
const alpha=(r,g,b)=>{const t=Math.max(0,Math.min(1,(g-Math.max(r,b)-.12)/.33));return 1-t*t*(3-2*t);};
for(const duration of [.72,.432,.12])for(const [phase,column] of [[.1,3],[.45,4],[.8,5]]){
  assert.equal(frame({actionUntil:duration,actionDuration:duration,actionAngle:0},duration*phase).column,column);
}
assert.equal(alpha(0,1,0),0);assert.equal(alpha(.8,.8,.8),1);assert.equal(alpha(.2,.8,1),1);
console.log('Front/back/left/right, walk frames, attack phases and chroma-key color checks passed.');
