const fs=require('node:fs');
const path=require('node:path');
const sharp=require('C:/Users/gs112/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp');
(async()=>{
const source=path.resolve('outputs/astra-ruined-star');
let html=fs.readFileSync(path.join(source,'index.html'),'utf8');
html=html.replace(/<link rel="stylesheet" href="\.\/([^"]+)">/g,(_,file)=>'<style>'+fs.readFileSync(path.join(source,file),'utf8')+'</style>');
html=html.replace(/<script src="\.\/([^"]+)"><\/script>/g,(_,file)=>{
  const script=fs.readFileSync(path.join(source,file),'utf8');
  return '<script>\n'+script.replace(/<\/script/gi,'<\\/script')+'\n</script>';
});
const background=await sharp(path.join(source,'assets/ruined-sanctuary-bg.png')).webp({quality:88}).toBuffer();
for(const match of [...html.matchAll(/<img src="\.\/([^\"]+)"/g)]){
  const portrait=await sharp(path.join(source,match[1])).resize({height:700,withoutEnlargement:true}).webp({quality:88}).toBuffer();
  html=html.replace(match[0],'<img src="data:image/webp;base64,'+portrait.toString('base64')+'"');
}
html=html.replace('./assets/ruined-sanctuary-bg.png','data:image/webp;base64,'+background.toString('base64'));
fs.mkdirSync('deployment',{recursive:true});
fs.writeFileSync('deployment/index.html',html);
for(const match of html.matchAll(/<script[^>]*>([\s\S]*?)<\/script>/g)){
  new Function(match[1].replace(/^\s*import .*;$/m,''));
}
if(html.includes('src="./'))throw new Error('Unbundled local script');
console.log('Vercel bundle: '+Buffer.byteLength(html)+' bytes');
})().catch(error=>{console.error(error);process.exitCode=1;});
