const fs=require('node:fs');
const path=require('node:path');
const source=path.resolve('outputs/astra-ruined-star');
let html=fs.readFileSync(path.join(source,'index.html'),'utf8');
html=html.replace(/<script src="\.\/([^"]+)"><\/script>/g,(_,file)=>{
  const script=fs.readFileSync(path.join(source,file),'utf8');
  return '<script>\n'+script.replace(/<\/script/gi,'<\\/script')+'\n</script>';
});
const background=fs.readFileSync(path.join(source,'assets/ruined-sanctuary-bg.png')).toString('base64');
html=html.replace('./assets/ruined-sanctuary-bg.png','data:image/png;base64,'+background);
fs.mkdirSync('deployment',{recursive:true});
fs.writeFileSync('deployment/index.html',html);
for(const match of html.matchAll(/<script[^>]*>([\s\S]*?)<\/script>/g)){
  new Function(match[1].replace(/^\s*import .*;$/m,''));
}
if(html.includes('src="./'))throw new Error('Unbundled local script');
console.log('Vercel bundle: '+Buffer.byteLength(html)+' bytes');
