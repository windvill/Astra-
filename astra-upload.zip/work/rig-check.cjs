const vm=require('node:vm'),fs=require('node:fs'),assert=require('node:assert/strict');
class Node {
  constructor(){this.children=[];this.position={set(x,y,z){Object.assign(this,{x,y,z});}};this.rotation={x:0,y:0,z:0};this.scale={set(){}};}
  add(...nodes){this.children.push(...nodes);}
}
class Material {constructor(){this.emissive={set(){}};}}
class Mesh extends Node{constructor(geometry,material){super();this.geometry=geometry;this.material=material;}}
const THREE={Group:Node,Mesh,MeshStandardMaterial:Material,BoxGeometry:class{},SphereGeometry:class{},OctahedronGeometry:class{}};
const context={window:{}};vm.createContext(context);
const html=fs.readFileSync('outputs/astra-ruined-star/index.html','utf8');
vm.runInContext([...html.matchAll(/<script([^>]*)>([\s\S]*?)<\/script>/g)][0][2],context);
vm.runInContext(fs.readFileSync('outputs/astra-ruined-star/astra-rig.js','utf8'),context);
const rig=context.window.createAstraRig(THREE);
rig.animate({moving:true,facingAngle:0},0);
rig.animate({moving:true,facingAngle:0},.05);
assert(rig.root.rotation.y>0,'character turns towards movement');
assert(rig.joints.leftLeg.hip.rotation.x*rig.joints.rightLeg.hip.rotation.x<0,'legs alternate');
assert(rig.joints.rightLeg.knee.rotation.x>0,'knee bends during stride');
rig.animate({moving:false,actionAngle:0,actionUntil:1.44},1.12);
const windup=rig.joints.rightArm.shoulder.rotation.x;
rig.animate({moving:false,actionAngle:0,actionUntil:1.44},1.25);
assert(rig.joints.rightArm.shoulder.rotation.x>windup,'raised arm lowers during overhead cut');
assert.equal(rig.joints.rightArm.shoulder.rotation.y,0,'cut stays vertical');
const pose=JSON.stringify(rig.joints.rightArm.shoulder.rotation);
rig.animate({moving:false,actionAngle:0,actionUntil:1.44},1.25);
assert.equal(JSON.stringify(rig.joints.rightArm.shoulder.rotation),pose,'paused simulation freezes joint pose');
assert(rig.joints.rightArm.hand.children.length>1,'weapon is parented to hand');
console.log('Rig checks passed: facing, alternating legs, knee flex, attack joints, frozen pose, attached weapon.');
