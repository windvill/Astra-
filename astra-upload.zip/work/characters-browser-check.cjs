const fs=require('node:fs'),assert=require('node:assert/strict');
const {chromium}=require('C:/Users/gs112/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
(async()=>{
 const browser=await chromium.launch({channel:'msedge',headless:true});
 try{fs.mkdirSync('work/qa',{recursive:true});for(const [width,height]of [[1280,720],[390,844]]){
  const page=await browser.newPage({viewport:{width,height}}),errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.goto('https://astra-pi-blond.vercel.app/',{waitUntil:'networkidle'});
  await page.locator('[data-menu="characters"]').click();
  await page.screenshot({path:`work/qa/characters-${width}.png`});
  assert.equal(await page.locator('.hero-choice img').evaluateAll(imgs=>imgs.filter(i=>i.complete&&i.naturalWidth>0).length),3);
  await page.locator('[data-hero="seer"]').click();await page.getByRole('button',{name:'이 인물로 출전',exact:true}).click();
  assert.equal(await page.locator('#selected-hero-name').textContent(),'세이르');
  await page.getByRole('button',{name:'이야기',exact:true}).click();await page.getByRole('tab',{name:'세 개의 맹세'}).click();
  assert(await page.getByRole('heading',{name:'서로 다른 과거, 하나의 길.'}).isVisible());await page.screenshot({path:`work/qa/story-${width}.png`});await page.keyboard.press('Escape');
  await page.getByRole('button',{name:'크레딧',exact:true}).click();assert(await page.getByText('개발 협업',{exact:true}).isVisible());await page.keyboard.press('Escape');
  await page.getByRole('button',{name:'원정 시작',exact:false}).click();await page.waitForTimeout(500);
  assert(await page.getByText('첫 번째 별의 표식',{exact:true}).isVisible());await page.screenshot({path:`work/qa/tutorial-${width}.png`});
  assert.equal(await page.locator('#tutorial-diagram kbd').filter({hasText:'W'}).count(),1);
  await page.getByRole('button',{name:'조작과 원정 시스템',exact:true}).click();
  const stopped=await page.locator('#timer').textContent();await page.keyboard.down('KeyD');await page.waitForTimeout(1100);await page.keyboard.up('KeyD');
  assert.equal(await page.locator('#timer').textContent(),stopped);
  assert(await page.getByRole('heading',{name:'생명력 · 경험치',exact:true}).isVisible());
  await page.screenshot({path:`work/qa/field-guide-${width}.png`});await page.keyboard.press('Escape');
  assert(await page.locator('#field-guide').isHidden());
  await page.keyboard.down('KeyD');await page.waitForTimeout(width>600?500:350);await page.keyboard.up('KeyD');
  await page.locator('#choices button').first().waitFor({state:'visible',timeout:15000});await page.locator('#choices button').first().click();
  await page.getByText('수련 완료',{exact:true}).waitFor({state:'visible'});await page.screenshot({path:`work/qa/tutorial-complete-${width}.png`});
  await page.getByRole('button',{name:'수련을 마치고 원정 시작',exact:true}).click();
  assert.equal(await page.locator('#hp-text').textContent(),'90 / 90');assert.equal(await page.locator('#level').textContent(),'1');
  await page.getByRole('button',{name:'일시정지',exact:true}).click();await page.getByRole('button',{name:'원정 종료',exact:true}).click();await page.getByRole('button',{name:'성소로 귀환',exact:true}).click();
  await page.locator('[data-menu="characters"]').click();await page.locator('[data-hero="warden"]').click();await page.getByRole('button',{name:'이 인물로 출전',exact:true}).click();
  await page.getByRole('button',{name:'원정 시작',exact:false}).click();await page.waitForTimeout(500);assert.equal(await page.locator('#hp-text').textContent(),'160 / 160');
  await page.screenshot({path:`work/qa/warden-${width}.png`});await page.reload({waitUntil:'networkidle'});assert.equal(await page.locator('#selected-hero-name').textContent(),'바르');
  assert.deepEqual(errors,[]);console.log(JSON.stringify({width,height,characters:3,tutorial:'complete',story:true,persistence:true,errors}));await page.close();
 }}finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
