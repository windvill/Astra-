const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const controls={};let starts=0,contexts=0;
const param=()=>({value:0,setValueAtTime(){},exponentialRampToValueAtTime(){},setTargetAtTime(v){this.value=v;}});
const node=()=>({gain:param(),frequency:param(),Q:param(),connect(){},disconnect(){},start(){starts++;},stop(){}});
class AudioContext{
  constructor(){contexts++;this.currentTime=1;this.sampleRate=48000;this.state='running';this.destination=node();}
  createGain(){return node();}createDynamicsCompressor(){return node();}createOscillator(){return node();}
  createBiquadFilter(){return node();}createBufferSource(){return node();}
  createBuffer(channels,length){return {getChannelData:()=>new Float32Array(length)};}
}
const sandbox={window:{AudioContext},localStorage:{getItem:()=>null,setItem(){}},document:{hidden:false,getElementById:id=>controls[id]??={},addEventListener(){}}};
vm.createContext(sandbox);vm.runInContext(fs.readFileSync('outputs/astra-ruined-star/astra-audio.js','utf8'),sandbox);
const audio=sandbox.window.AstraAudio;
assert.equal(contexts,0,'audio waits for user gesture');audio.unlock();audio.unlock();assert.equal(contexts,1);
for(const sound of ['swing','hit','hurt','gem','level','end'])audio.play(sound);
assert(starts>=10,'all sound families synthesize voices');const before=starts;audio.play('hit');assert.equal(starts,before,'duplicate hits throttled');
audio.tick(true);assert(starts>before,'music schedules notes');const paused=starts;audio.tick(false);assert.equal(starts,paused);
controls['audio-mute'].checked=true;controls['audio-mute'].onchange();audio.tick(true);assert.equal(starts,paused,'mute suppresses scheduling');
sandbox.document.hidden=true;audio.play('swing');assert.equal(starts,paused,'hidden tab stays silent');
console.log('Audio gesture, single context, effects, music, pause, mute and throttling passed.');
