const assert=require('node:assert/strict');
const {chromium}=require('C:/Users/gs112/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
(async()=>{
 const browser=await chromium.launch({channel:'msedge',headless:true});
 try{for(const [width,height] of [[390,844],[844,390]]){
  const page=await browser.newPage({viewport:{width,height},hasTouch:true,isMobile:true});const errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.goto('https://astra-pi-blond.vercel.app/',{waitUntil:'networkidle'});
  await page.getByRole('button',{name:'성소 수련 · 튜토리얼',exact:true}).click();
  await page.locator('#touch-controls').waitFor({state:'visible'});
  const cdp=await page.context().newCDPSession(page);
  assert.equal(await page.locator('.touch-stick').count(),1);
  const left=await page.locator('[data-stick=move]').boundingBox();
  const center=r=>({x:r.x+r.width/2,y:r.y+r.height/2});const l=center(left);
  const point=(id,p)=>({id,x:p.x,y:p.y,radiusX:5,radiusY:5,force:1});
  await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[point(1,l)]});
  await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[point(1,{x:l.x+left.width*.3,y:l.y})]});
  await page.waitForTimeout(width<600?350:900);
  const moving=await page.evaluate(()=>({...AstraTouch.state}));assert(moving.x>.8);
  await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});
  assert.equal(await page.evaluate(()=>AstraTouch.state.x),0);
  assert.notEqual(await page.locator('#tutorial-title').textContent(),'첫 번째 별의 표식');
  await page.screenshot({path:`work/qa/touch-${width}.png`});
  await page.getByRole('button',{name:'조작과 원정 시스템',exact:true}).click();await page.locator('#touch-controls').waitFor({state:'hidden'});
  await page.getByRole('button',{name:'닫기',exact:true}).click();await page.waitForTimeout(300);
  if(await page.locator('#levelup').isVisible())await page.locator('#choices button').first().click();
  await page.locator('#touch-controls').waitFor({state:'visible'});
  await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[point(3,{x:l.x-30,y:l.y})]});
  await cdp.send('Input.dispatchTouchEvent',{type:'touchCancel',touchPoints:[]});assert.equal(await page.evaluate(()=>AstraTouch.state.x),0);
  await page.locator('#tutorial-skip').click();
  await page.getByRole('button',{name:'일시정지',exact:true}).click();await page.locator('#touch-controls').waitFor({state:'hidden'});
  await page.getByRole('button',{name:'계속하기',exact:true}).click();await page.locator('#touch-controls').waitFor({state:'visible'});
  assert.equal(await page.evaluate(()=>AstraTouch.state.x),0);assert.deepEqual(errors,[]);
  console.log(JSON.stringify({width,height,singleStick:true,movementObjective:true,cancel:true,pause:true,errors}));await page.close();
 }}finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
